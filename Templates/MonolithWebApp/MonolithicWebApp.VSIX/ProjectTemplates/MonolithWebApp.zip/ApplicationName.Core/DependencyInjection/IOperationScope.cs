﻿namespace ApplicationName.Core.DependencyInjection
{
    public interface IOperationScope
    {
        string ScopeId { get; }
    }
}
