﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ApplicationName.Core.Log
{
    public class OutputLogBuilder : ILogBuilder
    {
        private IDictionary<string, string> _properties = new Dictionary<string, string>();
        private readonly string _message;
        private readonly string _severityLevel;
        private readonly string _operationScope;

        public OutputLogBuilder(string message, string severityLevel, string operationScope)
        {
            _message = message;
            _severityLevel = severityLevel;
            _operationScope = operationScope;
        }

        public void Log()
        {
            var propertiesString = string.Join(", ", _properties.Select(x => $"{x.Key}={x.Value}"));
            Debug.WriteLine($"{DateTime.UtcNow:yyyy.MM.dd HH:mm:ss:ffff} ({_operationScope}) {_severityLevel}: {_message} [{propertiesString}]");
        }

        public ILogBuilder WithProperty(string name, string value)
        {
            _properties[name] = value;
            return this;
        }
    }
}
