﻿using Newtonsoft.Json;
using NLog;
using System;
using System.Collections.Generic;

namespace ApplicationName.Core.Log
{
    public class LoggingItemBuilder
    {
        private readonly ILogger _logger;
        private readonly LogLevel _logLevel;
        private readonly IDictionary<string, string> _properties = new Dictionary<string, string>();

        private LoggingItemBuilder(ILogger logger, LogLevel logLevel)
        {
            _logger = logger;
            _logLevel = logLevel;
        }

        public static LoggingItemBuilder Create(ILogger logger, LogLevel logLevel, Guid scoperId, string message = null)
        {
            var builder = new LoggingItemBuilder(logger, logLevel);

            builder.WithProperty(LoggingPropertiesName.LogLevelProperty, logLevel.ToString());
            builder.WithProperty(LoggingPropertiesName.DateProperty, DateTime.Now.ToString());
            builder.WithProperty(LoggingPropertiesName.ScopeIdProperty, scoperId.ToString());

            if (!string.IsNullOrWhiteSpace(message))
            {
                builder.WithProperty(LoggingPropertiesName.MessageProperty, message);
            }

            return builder;
        }

        public LoggingItemBuilder WithProperty(string name, string value)
        {
            _properties[name] = value;

            return this;
        }

        public LoggingItemBuilder WithException(Exception exception)
        {
            _properties[LoggingPropertiesName.ExceptionMessageProperty] = exception.Message;
            _properties[LoggingPropertiesName.StackTraceProperty] = exception.StackTrace;

            return this;
        }

        public void Write()
        {
            var message = JsonConvert.SerializeObject(_properties);
            _logger.Log(_logLevel, message);
        }
    }
}
