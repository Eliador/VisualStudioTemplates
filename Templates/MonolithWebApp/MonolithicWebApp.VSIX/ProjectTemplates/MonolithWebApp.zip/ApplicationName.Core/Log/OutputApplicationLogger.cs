﻿using ApplicationName.Core.DependencyInjection;
using System;

namespace ApplicationName.Core.Log
{
    public class OutputApplicationLogger : IApplicationLogger
    {
        private readonly IOperationScope _operationScope;

        public OutputApplicationLogger(IOperationScope operationScope)
        {
            _operationScope = operationScope;
        }

        public ILogBuilder Error(string message)
        {
            return new OutputLogBuilder(message, "Error", _operationScope.ScopeId);
        }

        public void Exception(Exception exception, string message = null)
        {
            var builder = new OutputLogBuilder(message ?? exception.Message, "Fatal Error", _operationScope.ScopeId);
            builder.Log();
        }

        public ILogBuilder Information(string message)
        {
            return new OutputLogBuilder(message, "Info", _operationScope.ScopeId);
        }

        public ILogBuilder Warning(string message)
        {
            return new OutputLogBuilder(message, "Warning", _operationScope.ScopeId);
        }
    }
}
