﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationName.Core.Log
{
    public static class LoggingPropertiesName
    {
        public static string MessageProperty => "Message";
        public static string ExceptionMessageProperty => "Message";
        public static string DateProperty => "Date";
        public static string StackTraceProperty => "StackTrace";
        public static string LogLevelProperty => "LogLevel";
        public static string ScopeIdProperty => "ScopeId";
    }
}
