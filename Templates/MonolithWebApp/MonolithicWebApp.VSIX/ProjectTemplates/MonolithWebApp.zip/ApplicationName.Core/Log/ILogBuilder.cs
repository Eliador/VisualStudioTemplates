﻿namespace ApplicationName.Core.Log
{
    public interface ILogBuilder
    {
        ILogBuilder WithProperty(string name, string value);

        void Log();
    }
}
