﻿using System;

namespace ApplicationName.Core.Log
{
    public interface IApplicationLogger
    {
        ILogBuilder Information(string message);

        ILogBuilder Warning(string message);

        ILogBuilder Error(string message);

        void Exception(Exception exception, string message = null);
    }
}
