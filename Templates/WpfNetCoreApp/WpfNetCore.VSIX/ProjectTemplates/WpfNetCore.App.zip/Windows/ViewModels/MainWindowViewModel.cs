﻿using GalaSoft.MvvmLight;

namespace ProjectName.App.Windows.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        public string HelloWorldText => "Hello World!!";
    }
}
