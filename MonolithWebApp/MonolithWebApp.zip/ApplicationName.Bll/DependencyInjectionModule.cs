﻿using ApplicationName.Core.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;

namespace ApplicationName.Bll
{
    class DependencyInjectionModule : IDependencyInjectionModule
    {
        public void Load(IServiceCollection serviceCollection)
        {
        }
    }
}
