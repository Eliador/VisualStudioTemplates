﻿namespace ApplicationName.Core.Configuration
{
    public static class ApplicationSettings
    {
        public static string ConnectionString => "DefaultConnection";
    }
}