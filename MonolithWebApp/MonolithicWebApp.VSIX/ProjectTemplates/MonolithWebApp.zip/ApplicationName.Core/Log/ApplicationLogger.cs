﻿using ApplicationName.Core.DependencyInjection;
using NLog;
using System;

namespace ApplicationName.Core.Log
{
    public class ApplicationLogger : IApplicationLogger
    {
        private readonly ILogger _logger;
        private readonly IOperationScope _operationScope;

        public ApplicationLogger(ILogger logger, IOperationScope operationScope)
        {
            _logger = logger;
            _operationScope = operationScope;
        }

        public LoggingItemBuilder Info(string message)
        {
            return LoggingItemBuilder.Create(_logger, LogLevel.Info, _operationScope.ScopeId, message);
        }

        public LoggingItemBuilder Warn(string message)
        {
            return LoggingItemBuilder.Create(_logger, LogLevel.Warn, _operationScope.ScopeId, message);
        }

        public LoggingItemBuilder Error(Exception exception)
        {
            return LoggingItemBuilder.Create(_logger, LogLevel.Warn, _operationScope.ScopeId)
                .WithException(exception);
        }

        public LoggingItemBuilder Error(string message)
        {
            return LoggingItemBuilder.Create(_logger, LogLevel.Warn, _operationScope.ScopeId, message);
        }
    }
}
