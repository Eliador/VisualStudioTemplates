﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ApplicationName.Core.Log
{
    public interface IApplicationLogger
    {
        LoggingItemBuilder Info(string message);

        LoggingItemBuilder Warn(string message);

        LoggingItemBuilder Error(Exception exception);

        LoggingItemBuilder Error(string message);
    }
}
